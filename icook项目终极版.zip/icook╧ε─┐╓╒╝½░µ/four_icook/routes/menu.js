var express = require('express');
var router = express.Router();
const db=require('./../utils/db');

  router.get('/list.php',function(req, res) {
    let page_num=req.query.page_num
    let sql='SELECT * FROM users right OUTER JOIN recipe ON users.user_id=recipe.author '
    new Promise((resolve,reject)=>{
      db.connection(sql,[],(err,data)=>{
        if(!err){
          if(data.length>=1){
            resolve(data.length)
              }else{
            res.json({
              code:1,
              msg:'未找到数据',
            })
    
          }
        }else{
         reject(err)
    
        }
      })
    }).then(result=>{
      db.connection(sql,[],(err,data)=>{
        var count=data.length
      sql+=`limit ${(page_num-1)*12} ,12`
      db.connection(sql,[],(err,data)=>{
        if(!err){
          if(data.length!=0){
            res.json({
              code:0,
              msg:'ok',
              result:count,
              data,
            })
          }else{
            res.json({
              code:2,
              msg:"查找不到该数据"
            })
          }
        }else{
          res.json({
            code:1,
            msg:"查询失败"
          })
        }
      })
      }).catch(err=>{
        res.json({
          code:4,
          msg:'查询出错'
        })
      })
    })
  })
 
  router.get('/gradient.jsp',function(req, res) {
    let sql1='SELECT * FROM ingredients UNION ALL SELECT * FROM health UNION ALL SELECT * FROM  bake UNION ALL SELECT * FROM dishes'
   db.connection(sql1,[],(err,data)=>{
      if(!err){
        if(data.length>=1){
          res.json({
            code:0,
            msg:'ok',
            data,
          })
            }else{
          res.json({
            code:1,
            msg:'未找到数据',
          })
  
        }
      }else{
        console.log(err)
  
      }
    })
  })
    
  router.post('/render_list.php',function(req, res){
    let aa=req.body.respond
    let sql2=`SELECT * FROM ingredients WHERE ingredients_name='${aa}' UNION ALL SELECT * FROM health WHERE health_name='${aa}' UNION ALL SELECT * FROM  bake WHERE bake_name = '${aa}'UNION ALL SELECT * FROM dishes  WHERE dishes_name='${aa}' `
    new Promise((resolve,reject)=>{
      db.connection(sql2,[aa],(err,data)=>{
        if(!err){
          if(data.length>=1){
            resolve(data)
              }else{
            res.json({
              code:1,
              msg:'未找到数据',
            })
    
          }
        }else{
          reject(err)
          }
      })
    }).then(result=>{
      let sql3=''
      var count=result[0]
      var id=count.ingredients_id,reg=/^1/,reg2=/^2/,reg3=/^3/,reg4=/^4/
      if(reg.test(id)){
        sql3=`SELECT * FROM recipe WHERE sort_ingredients= (SELECT ingredients_id FROM ingredients WHERE ingredients_id=${id})`
      }else if(reg3.test(id)){
        sql3=`SELECT * FROM recipe WHERE sort_bake= (SELECT bake_id FROM bake WHERE bake_id=${id})`
      }else if(reg4.test(id)){
        sql3=`SELECT * FROM recipe WHERE sort_health= (SELECT health_id FROM health WHERE health_id=${id})`
      }else if(reg2.test(id)){
        sql3=`SELECT * FROM recipe WHERE sort_dish=(SELECT dishes_id FROM dishes WHERE dishes_id = ${id}) `
      }
      db.connection(sql3,[count],(err,data)=>{
        if(!err){
          if(data.length>=1){
            res.json({
             code:0,
             msg:'请求成功',
             data,
             send:count,
            })
          }else{
            res.json({
              code:1,
              msg:'无数据',
             })
          }
        }else{
          res.json({
            code:2,
            msg:'查询出错啦',
           })
        }
      }).catch(err=>{
        res.json({
          code:3,
          msg:'查询出错',
         })
      })
      
    })
    
  })

  router.post('/render_list2.php',function(req, res){
    let xx=req.body.respond
    let sql5=`SELECT * FROM ingredients WHERE ingredients_name='${xx}' UNION ALL SELECT * FROM health WHERE health_name='${xx}' UNION ALL SELECT * FROM  bake WHERE bake_name = '${xx}'UNION ALL SELECT * FROM dishes  WHERE dishes_name='${xx}' `
    new Promise((resolve,reject)=>{
      db.connection(sql5,[xx],(err,data)=>{
        if(!err){
          if(data.length>=1){
            resolve(data)
              }else{
            res.json({
              code:1,
              msg:'未找到数据',
            })
    
          }
        }else{
          reject(err)
          }
      })
    }).then(result=>{
      let sql4=''
      var count=result[0]
      var id=count.ingredients_id,reg=/^1/,reg2=/^2/,reg3=/^3/,reg4=/^4/
      if(reg.test(id)){
        sql4=`SELECT * FROM recipe WHERE sort_ingredients= (SELECT ingredients_id FROM ingredients WHERE ingredients_id=${id})`
      }else if(reg3.test(id)){
        sql4=`SELECT * FROM recipe WHERE sort_bake= (SELECT bake_id FROM bake WHERE bake_id=${id})`
      }else if(reg4.test(id)){
        sql4=`SELECT * FROM recipe WHERE sort_health= (SELECT health_id FROM health WHERE health_id=${id})`
      }else if(reg2.test(id)){
        sql4=`SELECT * FROM recipe WHERE sort_dish=(SELECT dishes_id FROM dishes WHERE dishes_id = ${id}) `
      }
      db.connection(sql4,[count],(err,data)=>{
        if(!err){
          if(data.length>=1){
            res.json({
             code:0,
             msg:'请求成功',
             data,
             send:count,
            })
          }else{
            res.json({
              code:1,
              msg:'无数据',
             })
          }
        }else{
          res.json({
            code:2,
            msg:'查询出错啦',
           })
        }
      }).catch(err=>{
        res.json({
          code:3,
          msg:'查询出错',
         })
      })
      
    })
    
  })

  module.exports = router;
  

