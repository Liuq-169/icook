$('.yhm').on('blur',function(){
    let str =$('.yhm').val();
    var patt1 = /^[1][3,4,5,7,8][0-9]{9}$/;
    
    if(($('.yhm').val().length==0)){
        $('.zh').html('手机号不能为空')
        yhm=false
    }else if(!patt1.exec(str)){
        $('.zh').html('手机号码格式错误')
        yhm=false
    }else{
        $('.zh').html('')
        yhm=true;
    }
})
var yhm=false,yhnc=false,hymm=false,mmqr=false;
$('.yhnc').on('blur',function(){
    if(($('.yhnc').val().length==0)){
        $('.nc').html('昵称不能为空')
        yhnc=false
    }else if(($('.yhnc').val().length<2)){
      $('.nc').html('请输入2~16个字的昵称')
      yhnc=false
    }else{
      $('.nc').html('')
      yhnc=true
    }
})
$('.yhmm').on('blur',function(){
    if(($('.yhmm').val().length==0)){
        $('.mm').html('密码不能为空')
        hymm=false
    }else if(($('.yhmm').val().length<6)){
      $('.mm').html('密码不能小于6位')
      hymm=false
    }else{
      $('.mm').html('')
      hymm=true;
    }
})
$('.qrmm').on('blur',function(){
    if($('.qrmm').val()!=$('.yhmm').val()){
      $('.qr').html('密码不一致')
      mmqr=false;
    }else{
      $('.qr').html('')
      mmqr=true;
    }
})
var urls='http://localhost:3000'
$('.dlu').on('click',function(){
  var username=$('.yhm').val()
  var password=$('.yhmm').val()
  var usernickname=$('.yhnc').val()
  if($('.xy')[0].checked){
    $('.xys').html('')
    if(yhm&&yhnc&&hymm&&mmqr){
      $.ajax({
        type:'get',
        url:urls+'/login/reg.php',
        data:{
          username:username,
          password:password,
          usernickname:usernickname
        },
        success(data){
            console.log(data)
            if(data.code==0){
              $('.xys').html(data.msg)
            }else{
              $('.xys').html(data.msg)
            }

        }
      })
    }else{
      $('.xys').html('注册信息有误，请检查后重新提交')
    }
  }else{
    $('.xys').html('请勾选协议')
  }
})
