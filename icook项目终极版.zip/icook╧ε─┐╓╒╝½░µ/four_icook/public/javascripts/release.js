var releaseStepArr=[]//步骤数组

/****封面图片展示****/
var unnlodeCover=document.querySelector('#unloadCover')
var coverText=document.querySelector('#coverText')
  unloadCover.addEventListener('change',function(){
    console.log(this.files);
    for(let i=0;i<this.files.length;i++){
        var file=this.files[i]
        console.log(file);
        coverText.innerHTML=file.name

        var fr = new FileReader();              
                fr.readAsDataURL(file);                 
                fr.onload = function () {
                    console.log(this.result); 
                    $('.showImg img').attr('src',this.result)           
                    $('.showImg img').css({
                        'width': '600px',
                        'height': '400px'
                    })          
                }
    }
})
  

/***生成步骤条**/
$('#moreStep').on('click',()=>{
    // console.log($('.steps').length);
    let len=$('.steps').length
    $('#step').append(`
    <div class="steps">
    <h5>步骤 ${len+1}</h5>
      <textarea class="form-control releaseStep"></textarea>
  </div>
    `)
})
/*------步骤上移、下移、添加、删除-----*/
    

/**标签**/
$('#collapseExample .card').on('click','span',function(){
    /***BUG标记 此处监听使用箭头函数this反而指向了window***/
    console.log($(this));
   let thisBtn= $(this).clone()
   $(this).remove()
   $('#showLabel').append(thisBtn)
})
$('#showLabel').on('click','.btn',function(){
    console.log($(this));
   let removeBtn= $(this).clone()
   $(this).remove()
   $('#collapseExample .card').append(removeBtn)
})

/**收取用户输入的内容***/

function integratInput(){
    //封面
    
    //菜谱名称
     var reicpeName=$('#reicpeName').val()
    // console.log($('#reicpeName').val());
    //背后故事
    var uploadStory=$('#uploadStory').val()
   //步骤\
   var releaseSteps=document.querySelectorAll('.releaseStep')
        // console.log(releaseSteps,releaseSteps.length);
           
        releaseStepArr.splice(0)
  for(var i=0,l= releaseSteps.length;i<l;i++){
      console.log($(releaseSteps[i]).val());
      releaseStepArr.push($(releaseSteps[i]).val())
  }
  var stepStr=releaseStepArr.join(',')
  console.log(stepStr);
//   var releaseStepObj={...releaseStepArr}
//    console.log(releaseStepObj);
   //发布时间
   var date=new Date().toLocaleDateString()
//    console.log(date);
   //选择分类、菜式、烘焙、养生
   var ingredientsVal=$('.choseIngredients').val()//食材
   var dishesVal=$('.choseDishes').val()//菜式
   var bakeVal=$('.choseBake').val()//烘焙
   var healthVal=$('.choseHealth').val()//养生

   //关键词
    var labelStr=''
    for(let i=0,labelLen=$('#showLabel span').length;i<labelLen;i++){
        labelStr+=$('#showLabel span')[i].innerHTML
    }
    // console.log(labelStr);
    return {reicpeName,uploadStory,stepStr,
        date,ingredientsVal,dishesVal,bakeVal,healthVal,labelStr}
}
