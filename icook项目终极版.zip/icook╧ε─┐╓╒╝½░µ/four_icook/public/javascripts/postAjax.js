
var dataImg=''
   

//上传图片
function doUpload(){
  let file = $('#unloadCover').get(0).files[0] 
  console.log(file);
  let formdata = new FormData()
formdata.append('hehe', file) 
console.log(formdata);
$.ajax({
    url:'/release/uploadImg.do',
    type:'post',
    cache:false,
    contentType:false,
    processData:false,
    data:formdata,
     
    success(data){
      console.log('上传成功');  
      console.log(data);
      dataImg=data.img
    }
})

}
 //发送文字信息
function uploadMsg(){
  
  console.log(integratInput().releaseStepObj);
$.ajax({
    type:'post',
    url:'/release/uploadText.php',
    data:{
      // var a=sessionStorage.getItem('user_id')
      author: sessionStorage.getItem('user_id'),//作者 
      recipe_title:integratInput().reicpeName,//标题
      recipe_keywords:integratInput().labelStr,//关键词
      info:integratInput().uploadStory,//背后故事
      img:`/uploads${dataImg}`,
      recipe_step:integratInput().stepStr,//步骤
      uptime:integratInput().date,//上传日期
      collect:0,//收藏数 新帖子初始为0
      sort_ingredients:`${integratInput().ingredientsVal}`,//食材
      sort_bake:integratInput().bakeVal,//烘焙
      sort_dish:integratInput().dishesVal,//菜式
      sort_health:integratInput().healthVal,//养生
      like_num:0//点赞数 新帖子初始为0

    },
    success(res){
      if(res.code==0){
        console.log('上传成功' ,res.msg)
        getReleaseID()
      }else{
        console.log('上传失败',res.msg);
      }
    },
    error(err){
        console.log('上传失败');
        console.log(err);
    }
})
}

//拿到返回的菜谱id与菜式并跳转详情菜谱页面
  function getReleaseID(){$.ajax({
      type:'get',
      url:'/release/getReleaseID.do',
      data:{},
      success(res){
         console.log(res.recipe_id,res.sort_dish);
         sessionStorage.setItem('recipe_id',res.recipe_id)
         sessionStorage.setItem('sort_dish',res.sort_dish)
          window.location.href='/works/details.html'
      }
  })
  }
