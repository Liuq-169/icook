
$('.zhtext').on('blur',function(){
    let str =$('.zhtext').val();
    var patt1 = /^[1][3,4,5,7,8][0-9]{9}$/;
    if(($('.zhtext').val().length==0)){
        $('.dlzz').html('手机号不能为空')
        yhm=false
    }else if(!patt1.exec(str)){
        $('.dlzz').html('手机号码格式错误')
        yhm=false
    }else{
        $('.dlzz').html('')
        yhm=true;
    }
    
})
var yhm=false,hymm=false;
$('.mmtext').on('blur',function(){
    if(($('.mmtext').val().length==0)){
        $('.dlzz').html('密码不能为空')
        hymm=false
    }else if(($('.mmtext').val().length<6)){
      $('.dlzz').html('密码不能小于6位')
      hymm=false
    }else{
      $('.dlzz').html('')
      hymm=true;
    }
})
var urls='http://localhost:3000'
// var logins=function(){
//     $.ajax({
//         type:'get',
//         url:url+`../login/login.php?username=${username}&password=${password}`,
//         success(data){
//             console.log(data)
//         }
//     })
// }
 var username=0;
 var password=0;
$('.dlu').on('click',function(){
    username=$('.zhtext').val();
    password=$('.mmtext').val();
    // logins();
    if(hymm&&yhm){
        $.ajax({
            type:'post',
            url:urls+'/login/login.php',
            data:{
                username:username,
                password:password,
            },
            success(data){
                console.log(data)
                if(data.code==0){
                    sessionStorage.setItem('user_id',data.data[0].user_id)
                    sessionStorage.setItem('headlogo',data.data[0].headlogo)
                    sessionStorage.setItem('signstr',data.signstr)
                    $('.dlzz').html(data.msg)
                    setTimeout(function() {
                        window.location.href='/html/index.html'
                    }, 100)
                }
                if(data.code!=0){
                    $('.dlzz').html(data.msg)
                }
            }
        })
    }else{
        if($('.dlzz').html()==''){
            $('.dlzz').html('用户名不能为空')
        }
    }
})

