var pageNode = document.getElementsByClassName('page')[0]
class getPage {
    constructor(ele, sum) {
        this.ele = ele  //节点
        this.sum = sum  //商品数量
        this.init()     //页面节点的渲染
    }
    init() {
        var str = ''
        str = `
                <button class="btn btn-primary" id='btn_head'>首页</button>
                <button class="btn btn-primary" id='per'>上一页</button>
              `
        for (var i = 0; i < pageCount; i++) {
            str += `<input type="button" class="btn btn-primary inp" value="${i + 1}" index="${i}">`
        }
        str += `<button class="per btn btn-primary" id='next'>下一页</button>
                <button class="btn btn-primary" id='btn_food'>尾页</button>
               `
        pageNode.innerHTML = str
    }
}