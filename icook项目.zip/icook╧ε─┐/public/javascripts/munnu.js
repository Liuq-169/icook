//取消默认选中
window.onselectstart=function(e){
    e.preventDefault()
}
// 添加导航栏点击效果
$('.nav-link').on('click',function(){
   $('.nav-link').removeClass('current')
   $(this).addClass('current')
})
// 食材点击触发ajax请求
$('#gradient').on('click',function(){
   window.location.href='http://localhost:3000/html/menu_ingre.html'
})

// 渲染精选页面数据fn
let page_num=1
function getList(){
    let base_url='http://localhost:3000'
    $.ajax({
        type:'get',
        url:base_url+`/menu/list.php?page_num=${page_num}`,
        success(res){
            if(res.code==0){
                var str='',strs=''
                for(var i=0;i<res.data.length;i++){
                    if(res.data[i].img.substring(0,4)==='http'){
                        strs=res.data[i].img
                    }else{
                        strs+='..'+res.data[i].img
                    }
                    str+=`<div class='card'>
                    <img src=${strs} class="card-img-top inner_img" altss=${res.data[i].recipe_id} altss_type=${res.data[i].sort_dish}>
                    <div class="card-body">
                      <h5 class="card-title" title='${res.data[i].recipe_title}'altspan=${res.data[i].recipe_id} altspan_type=${res.data[i].sort_dish}>${res.data[i].recipe_title}</h5>
                      <p class="card-text" title='${res.data[i].info}'>${res.data[i].info}</p>
                      <img src=${res.data[i].headlogo} class='user_logo' author=${res.data[i].author}> 
                      <span class="user_text">${res.data[i].user_nickname}</span>
                    </div>
                  </div>`
                }
                $('.cendata').html(str)
                var pagefoot=new Page($('.page'),res.result)
                pagefoot.click()
                $('.inner_img').on('click',function(){
                    window.location.href='http://localhost:3000/works/details.html'
                    window.sessionStorage.setItem('recipe_id',`${$(this).attr('altss')}`)
                    window.sessionStorage.setItem('sort_dish',`${$(this).attr('altss_type')}`)
                })
                $('.card-title').on('click',function(){
                    window.location.href='http://localhost:3000/works/details.html'
                    window.sessionStorage.setItem('recipe_id',`${$(this).attr('altspan')}`)
                    window.sessionStorage.setItem('sort_dish',`${$(this).attr('altspan_type')}`)
                })
                $('.user_logo').on('click',function(){
                    window.location.href='http://localhost:3000/html/person_otherindex.html'
                    window.sessionStorage.setItem('person_id',`${$(this).attr('author')}`)
                })

             }
        },
        err(){
            console.log(err)
        }
    })
}
getList()

// 分页器
let x=0
class Page{
    constructor(parent,totalPage){
        this.parent=parent
        this.page=Math.ceil(totalPage/12)
        this.init()
    }
    init(){
       var str='',sss=''
       str=`<li id='first'>首页</li><li id='pre'><</li><div id=inner_box><div id='inner_inner_box'></div></div>`
       for(let i=0;i<this.page;i++){
        sss+=`<li class='page_item'>${i+1}</li>`
       }
       str+=`<li id='next'>></li><li id='last'>尾页</li>`
       this.parent.html(str)
       $('#inner_inner_box').html(sss)
    }
    click(){
        var that_page=this.page
       $('.page li').on('click',function(ev){
        $('.page li').css({
            'background-color':'white',
            'color':'rgb(236, 164, 7)'
        })
        var ev = ev || window.event;
        var oLi =ev.target;
        oLi.style.background='rgb(236, 164, 7)'
        oLi.style.color='white'
        if(oLi.innerHTML==='首页'){
                page_num=1
                $('body,html').animate({'scrollTop':0},500);
                getList()
        }
      if(oLi.innerHTML==='尾页'){
                page_num= that_page
                $('body,html').animate({'scrollTop':0},500);
                getList()
                setTimeout(()=>{
                    if(page_num>=5 ){
                    $('#inner_inner_box').animate({},'slow',function(){
                       $(this).css({'transform':`translateX(-160px)`}); 
                 })
                    
                }
               },1500)
      }
   })
   $('.page_item').on('click',function(){
    page_num=$(this)[0].innerHTML
    $('body,html').animate({'scrollTop':0},500);
    getList()
    x-=40
    setTimeout(()=>{
         if(page_num>=5&& page_num<=that_page){
             var that=this
         $('#inner_inner_box').animate({},'slow',function(){
            $(this).css({'transform':`translateX(${x}px)`}); 
            $(that).addClass('curr') 
         })
         
     }
    },1500)
   })
   $('#pre').on('click', function () {
        x+=40
       if (page_num != 1) {
           page_num--
           setTimeout(()=>{
            if(page_num>=5 ){
                var that=this
            $('#inner_inner_box').animate({},'slow',function(){
               $(this).css({'transform':`translateX(${x}px)`}); 
               $(that).addClass('curr') 
            })
            
        }
       },1500)
          }
        $('body,html').animate({'scrollTop':0},500);
       getList()
      
   })
   $('#next').on('click', function () {
                x-=40
               if (page_num != that_page) {
                   page_num++
                   setTimeout(()=>{
                    if(page_num>=5 ){
                        var that=this
                    $('#inner_inner_box').animate({},'slow',function(){
                       $(this).css({'transform':`translateX(${x}px)`}); 
                       $(that).addClass('curr') 
                    })
                    
                }
               },1500)
               }
               $('body,html').animate({'scrollTop':0},500);
               getList()
             
       })
    }
}






