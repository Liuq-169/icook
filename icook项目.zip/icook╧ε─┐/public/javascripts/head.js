var urls='http://localhost:3000'
$('.sous').on('click',function(){
    search()
})
//判断登录状态
window,addEventListener("load",function(){
    $.ajax({
        type:'post',
        url:urls+'/login/shuaxin.do',
        data:{},
        success(data){
            console.log(data)
            if(data.code==0){
                $('.grzx').removeClass('yingchang')
                if(sessionStorage.getItem('headlogo')!=""){
                    $('.br50')[0].src=sessionStorage.getItem('headlogo')
                }
                console.log(sessionStorage.getItem('headlogo'))
                $('.mydl').addClass('yingchang')
            }
            if(data.code==1){
                sessionStorage.removeItem('user_id')
            sessionStorage.removeItem("signstr");
                $('.grzx').addClass('yingchang')
                $('.mydl').removeClass('yingchang')
            }
        }
    })
})
//搜索框获取焦点
$('.keywords').on('focus',function(){
    $('.souslist').removeClass('yingchang')
})
$('.keywords').on('blur',function(){
    setTimeout(function(){
        $('.souslist').addClass('yingchang')
    },500)
})
//搜索框回车搜索
$('.keywords').keydown(function(event){
    // console.log(event.keyCode,'按下')
    if(event.keyCode==13){
        console.log('回车')
        search()
    }
})

//点击搜索框下面的列表推荐
$('.souslist').on('click','.csor',function(event){
    console.log($(event.target).attr('data-typesid'))
    console.log($(event.target).html().slice(2,6))
    let leiss=$(event.target).html().slice(2,6);
    $('.keywords').val(leiss)
        var keywords=$(event.target).attr('data-typesid');
        $('.leirongboxs').html('')
        let sskj=`<div class="sstab">
        <a class="a csor sstabxz   ssjgcp" href="#" class="active">菜谱</a>
        <a class="a csor ssjgcd"  href="#">菜单</a class="a csor">
        <a class="a csor ssjgyh"  href="#">用户</a class="a csor">
                    </div>
                    <div class="sstsbi">“${leiss}”的相关菜谱</div>
                    <div class="scllzg" style="margin-bottom:10px;">
                        <a href="#" class="scllzgxz a">综合最佳</a>|<a href="#" class="a">收藏最多</a>|<a href="#" class="a">做过最多</a>
                    </div>
                    <div class="sszsbox">
                    <div class="container ingred">
                        <div class="cendatass"></div>
                    </div>
                </div>`
        $('.ssjieguobox').html(sskj);
            $.ajax({
                type:'post',
                url:urls+'/login/searchlist.php',
                data:{
                    keywords:keywords
                },
                success(data){
                    console.log(data)
                    if(data.code==0){
                        if(data.code==0){
                            var str=''
                            for(var i=0;i<data.data.length;i++){
                                str+=`<div class='card'>
                                <img src=${data.data[i].img} class="card-img-top inner_img" alt="...">
                                <div class="card-body">
                                <h5 class="card-title" title='${data.data[i].recipe_title}'>${data.data[i].recipe_title}</h5>
                                <p class="card-text" title='${data.data[i].info}'>${data.data[i].info}</p>
                                <img src=${data.data[i].headlogo} class='user_logo'>
                                <span class="user_text">${data.data[i].user_nickname}</span>
                                </div>
                            </div>`
                            }
                            $('.cendatass').html(str)
                        }
                    }
                    if(data.code==1){
                        
                    }
                }
            })
})

//搜索封装
var search=function(){
    var keywords=$('.keywords').val();
    // logins();
    if(keywords!=''){
        $.ajax({
            type:'post',
            url:urls+'/login/search.php',
            data:{
                keywords:keywords
            },
            success(data){
                
    $('.leirongboxs').html('')
                console.log(data)
                if(data.code==0){
                    let sskj=`<div class="sstab">
                    <a class="a csor sstabxz   ssjgcp" href="#" class="active">菜谱</a>
                    <a class="a csor ssjgcd"  href="#">菜单</a class="a csor">
                    <a class="a csor ssjgyh"  href="#">用户</a class="a csor">
                            </div>
                            <div class="sstsbi">“${keywords}”的相关菜谱</div>
                            <div class="scllzg" style="margin-bottom:10px;">
                                <a href="#" class="scllzgxz a">综合最佳</a>|<a href="#" class="a">收藏最多</a>|<a href="#" class="a">做过最多</a>
                            </div>
                            <div class="sszsbox">
                            <div class="container ingred">
                                <div class="cendatass"></div>
                            </div>
                            </div>`
                    $('.ssjieguobox').html(sskj);
                    var str=''
                    for(var i=0;i<data.data.length;i++){
                        str+=`<div class='card'>
                        <img src=${data.data[i].img} class="card-img-top inner_img" alt="...">
                        <div class="card-body">
                        <h5 class="card-title" title='${data.data[i].recipe_title}'>${data.data[i].recipe_title}</h5>
                        <p class="card-text" title='${data.data[i].info}'>${data.data[i].info}</p>
                        <img src=${data.data[i].headlogo} class='user_logo'>
                        <span class="user_text">${data.data[i].user_nickname}</span>
                        </div>
                    </div>`
                    }
                    $('.cendatass').html(str)
                }
                if(data.code==1){
                    let sskj=`<div class="sstab">
                    <a class="a csor sstabxz   ssjgcp" href="#" class="active">菜谱</a>
                    <a class="a csor ssjgcd"  href="#">菜单</a class="a csor">
                    <a class="a csor ssjgyh"  href="#">用户</a class="a csor">
                            </div>
                            <div class="sstsbi">没有“${keywords}”的相关菜谱</div>
                            <div class="scllzg" style="margin-bottom:10px;">
                                <a href="#" class="scllzgxz a">看看别人都在搜索什么</a>
                            </div>
                            <div class="sszsbox">
                            <div class="container ingred">
                                <div class="cendatass"></div>
                            </div>
                        </div>`
                $('.ssjieguobox').html(sskj);
                $.ajax({
                    type:'post',
                    url:urls+'/login/search.php',
                    data:{
                        keywords:'肉'
                    },
                    success(data){
                        console.log(data)
                        if(data.code==0){
                            var str=''
                            for(var i=0;i<data.data.length;i++){
                                str+=`<div class='card'>
                                <img src=${data.data[i].img} class="card-img-top inner_img" alt="...">
                                <div class="card-body">
                                <h5 class="card-title" title='${data.data[i].recipe_title}'>${data.data[i].recipe_title}</h5>
                                <p class="card-text" title='${data.data[i].info}'>${data.data[i].info}</p>
                                <img src=${data.data[i].headlogo} class='user_logo'>
                                <span class="user_text">${data.data[i].user_nickname}</span>
                                </div>
                            </div>`
                            }
                            $('.cendatass').html(str)
                        }
                    }
                })
                }
            }
        })
    }else{
        console.log('搜索框不能为空')
    }
}

//用户搜索
$(document).on('click','.ssjgyh',function(){
    var keywords=$('.keywords').val();
    // logins();
    if(keywords!=''){
        $.ajax({
            type:'post',
            url:urls+'/login/searchyh.php',
            data:{
                keywords:keywords
            },
            success(data){
                console.log(data)
                if(data.code==0){
                        let sskj=`<div class="sstab">
                        <a class="a csor    ssjgcp" href="#" class="active">菜谱</a>
                        <a class="a csor ssjgcd"  href="#">菜单</a class="a csor">
                        <a class="a csor sstabxz ssjgyh"  href="#">用户</a class="a csor">
                        </div>
                        </div>
                            <div class="sstsbi">“${keywords}”的相关用户</div>
                            <div class="sszsbox">
                            <div class="container ingred">
                                <div class="ssperson_content_one"></div>
                            </div>
                            </div>`
                    $('.ssjieguobox').html(sskj);
                    
                    var str=''
                    for(var i=0;i<data.data.length;i++){
                        str+=`<div class='sspeople_been' data-id=${data.data[i].user_id} data-sex=${data.data[i].user_sex} data-name=${data.data[i].user_name}>
                                <div>
                                    <div><img src=${data.data[i].headlogo}></div>
                                    <div><button>+ 关注</button></div>
                                </div>
                                <div>
                                    <p>${data.data[i].user_nickname}</p>
                                    <p>记录达人，视频达人</p>    
                                </div>
                         </div>`
                    }
                    $('.ssperson_content_one').html(str)
                }
                if(data.code==1){
                    let sskj=`<div class="sstab">
                            <a class="a csor  ssjgcp" href="#" class="active">菜谱</a>
                            <a class="a csor ssjgcd"  href="#">菜单</a class="a csor">
                            <a class="a csor sstabxz ssjgyh"  href="#">用户</a class="a csor">
                            </div>
                            <div class="sstsbi">没有“${keywords}”的相关用户</div>
                            <div class="scllzg" style="margin-bottom:10px;">
                                <a href="#" class="scllzgxz a">搜索其他试试</a>
                            </div>
                        </div>`
                $('.ssjieguobox').html(sskj);
                }
            }
        })
    }else{
        console.log('搜索框不能为空')
    }
})
$(document).on('click','.ssjgcp',function(){
    search();
})
//退出登录
$('.out').on('click',function(){
    console.log('点击')
    $.ajax({
        type:'get',
        url:urls+'/login/destroy.do',
        data:{},
        success(data){

            console.log(data)

            if(data.code==0){

            }else{

            }
            sessionStorage.removeItem("user_id");
            sessionStorage.removeItem("signstr");
            
            window.location.reload()
        }
    })
})

//跳转菜谱
$('.caipuhover').on('click',function(){
    window.location.href='/html/menu.html'
    console.log('aa')
})
//跳转个人中心
$(document).on('click','.grzxbox',function(){
    window.location.href="/person_index.html"
})
//跳转发布
$(document).on('click','.fabulist',function(){
    window.location.href="/html/release.html"
})
