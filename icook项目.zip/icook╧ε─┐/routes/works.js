var express = require('express');
const db = require('../utils/db.js')
var router = express.Router();

router.get('/', function (req, res, next) {
    res.send('respond with a resource');
});

/**
    最新菜单的路由拦截
 */
router.get('/works.html', function (req, res) {
    res.render('works', { title: 'works' });
});
router.get('/getList.php', function (req, res) {
    var page_num = req.query.page_num
    var page_count = req.query.page_count
    let sql = `SELECT * FROM users RIGHT OUTER JOIN recipe ON users.user_id=recipe.author ORDER BY 
                recipe.like_num+recipe.collect DESC `
    db.connection(sql, [], (err, data) => {
        dataLen = data.length
        console.log(dataLen)
        if (!err) {
            if (data.length > 0) {
                sql += `LIMIT ${(page_num - 1) * page_count},${page_count}` 
                db.connection(sql, [], (err_inner, data_inner) => {                         
                    if (!err_inner) {
                        if (data_inner.length != 0) {
                            res.json({
                                code: 0,
                                msg: 'ok',
                                list_count: dataLen,
                                data: data_inner
                            })
                        } else {
                            res.json({
                                code: 2,
                                msg: "未找到数据"
                            })
                        }
                    } else {
                        res.json({
                            code: 1,
                            msg: "查询失败"
                        })
                    }
                })
            } else {
                res.json({ code: 1, msg: '未查询到数据!' })
            }
        } else {
            res.json({ code: 2, msg: '错误' })
        }
    })
})

/**
    正在流行 的路由拦截
 */
router.get('/works_liuxing.html', function (req, res) {
    res.render('works_liuxing', { title: 'works_liuxing' });
});
router.get('/getList_liuxingL.php', (req, res) => {
    let sql = 'SELECT * FROM users right OUTER JOIN recipe ON users.user_id=recipe.author ORDER BY recipe.like_num DESC LIMIT 10,40'
    db.connection(sql, [], (err, data) => {
        if (!err) {
            if (data.length >= 1) {
                res.json({ code: 0, msg: 'ok', data })
            } else {
                res.json({ code: 1, msg: '未查询到数据!' })
            }
        } else {
            res.json({ code: 2, msg: '错误!' })
        }
    })
})

router.get('/getList_liuxingR.php', (req, res) => {
    let sql = 'SELECT * FROM users right OUTER JOIN recipe ON users.user_id=recipe.author ORDER BY recipe.collect DESC LIMIT 5,5'
    db.connection(sql, [], (err, data) => {
        if (!err) {
            if (data.length >= 1) {
                res.json({ code: 0, msg: 'ok', data })
            } else {
                res.json({ code: 1, msg: '未查询到数据!' })
            }
        } else {
            res.json({ code: 2, msg: '错误!' })
        }
    })
})


/**
    菜谱详情 的路由拦截
 */

router.get('/details.html', function (req, res) {
    res.render('details', { title: 'datails' })
});

router.get('/getList_detailsL_one.php', (req, res) => {
    let recipe_id = req.query.recipe_id
    console.log(recipe_id)
    let sql = `SELECT * FROM users right OUTER JOIN recipe ON users.user_id=recipe.author where recipe.recipe_id=${recipe_id}`
    db.connection(sql, [], (err, data) => {
        if (!err) {
            if (data.length >= 1) {
                res.json({ code: 0, msg: 'ok', data })
            } else {
                res.json({ code: 1, msg: '未查询到数据!' })
            }
        } else {
            res.json({ code: 2, msg: '错误!' })
        }
    })
})

router.get('/getList_datailsR.php', (req, res) => {
    let sort_dish = req.query.sort_dish
    let sql = `SELECT * FROM users right OUTER JOIN recipe ON users.user_id=recipe.author where recipe.sort_dish=${sort_dish} ORDER BY recipe.collect LIMIT 1,5`
    db.connection(sql, [], (err, data) => {
        if (!err) {
            if (data.length >= 1) {
                res.json({ code: 0, msg: 'ok', data })
            } else {
                res.json({ code: 1, msg: '未查询到数据!' })
            }
        } else {
            res.json({ code: 2, msg: '错误!' })
        }
    })
})

router.get('/getInfo.php',(req,res)=>{
    let recipe_id = req.query.recipe_id
    let sql = `SELECT * FROM users right OUTER JOIN recipe ON users.user_id=recipe.author where recipe.recipe_id=${recipe_id}`
    db.connection(sql, [], (err, data) => {
        if (!err) {
            if (data.length >= 1) {
                res.json({ code: 0, msg: 'ok', data })
            } else {
                res.json({ code: 1, msg: '未查询到数据!' })
            }
        } else {
            res.json({ code: 2, msg: '错误!' })
        }
    })
})

/*------- chat -----------*/

router.get('/getChatList.php',(req,res)=>{
    let sql = `SELECT * FROM chat LEFT OUTER JOIN users ON chat.user_id=users.user_id ORDER BY chat.chat_id DESC LIMIT 0,50`
    db.connection(sql,[],(err,data)=>{
        if(!err){
            if(data.length>=1){
                res.json({code:0,msf:'ok',data})
            }else{
                res.json({code:1,msg:'未查询到聊天数据'})
            }
        }else{
            res.json({code:2,msg:'err'})
        }
    })
})

router.post('/postSubmit.php',(req,res)=>{
    let signstr = req.body.signstr
    let user_id = req.body.user_id
    let sql = `SELECT * FROM users where user_id = ${user_id}`
    db.connection(sql,[],(err,data)=>{
        if(!err){
            if(data.length>=1){
                res.json({code:0,msg:'ok',data})
            }else{
                res.json({code:1,msg:'未查询到数据'})
            }
        }else{
            res.json({code:2,msg:'错误'})
        }
    })
})

router.post('/postchat_Sql.php',(req,res)=>{
    let chatTxt = req.body.chatTxt
    let chatTime = req.body.chatTime
    let userId = req.body.userId
    let sql = `insert into chat(chat_txt,chat_time,user_id) values(?,?,?)`
    db.connection(sql,[chatTxt,chatTime,userId],(err,data)=>{
        if(!err){
            if(data.length>=1){
                res.json({code:0,msg:'添加到数据库'})
            }else{
                res.json({code:1,msg:'未检测到数据'})
            }
        }else{
            res.json({code:2,msg:'err'})
        }
    })
})

/** ----------- 收藏 ---------- */
router.post('/postCollect.php',(req,res)=>{
    let recipeId = req.body.recipeId
    let collectionNum = req.body.collectionNum
    let sql = `UPDATE recipe SET collect=${collectionNum} WHERE recipe_id=${recipeId}`
    db.connection(sql,[],(err,data)=>{
        if(!err){
            if(data.length>=1){
                res.json({code:0,msg:'成功修改数据库的收藏数!'})
            }else{
                res.json({code:1,msg:'修改数据库中的收藏数失败!'})
            }
        }else{
            res.json({code:2,msg:'err'})
        }
    })
})


module.exports = router;