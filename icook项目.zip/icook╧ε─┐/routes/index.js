var express = require('express');
const db=require('./../utils/db.js')
var router = express.Router();

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('/index', { title: 'Express' });
});

router.get('index.html',function(req,res){
  // res.render('index', { title: 'index' });
})



// 菜谱
router.get('/getList.php',(req,res)=>{
  let sql = 'SELECT * FROM users RIGHT OUTER JOIN recipe ON users.user_id=recipe.author limit 8';
  db.connection(sql,[],(err,data)=>{
    if(!err){
      if(data.length>0){
        // 查询总条数
        // data
        res.json({code:0,msg:'成功',data})
      }else{
        res.json({code:1,msg:'未查询到数据_总条数'})
      }
    }else{
      res.json({code:2,msg:'错误'})
    }
  })
})

// 食材
router.get('/getFile.php',(req,res)=>{
  let sql = 'select * from ingredients limit 6';
  db.connection(sql,[],(err,data)=>{
    if(!err){
      if(data.length>0){
        // 查询总条数
        // data
        res.json({code:0,msg:'成功',data})
      }else{
        res.json({code:1,msg:'未查询到数据_总条数'})
      }
    }else{
      res.json({code:2,msg:'错误'})
    }
  })
})

// 作品
router.get('/getWork.php',(req,res)=>{
  let sql = 'SELECT * FROM users RIGHT OUTER JOIN recipe ON users.user_id=recipe.author limit 4';
  db.connection(sql,[],(err,data)=>{
    if(!err){
      if(data.length>0){
        // 查询总条数
        // data
        res.json({code:0,msg:'成功',data})
      }else{
        res.json({code:1,msg:'未查询到数据_总条数'})
      }
    }else{
      res.json({code:2,msg:'错误'})
    }
  })
})

//厨房达人
router.get('/getStar.php',(req,res)=>{
  let sql = 'SELECT user_nickname,headlogo FROM users LIMIT 20';
  db.connection(sql,[],(err,data)=>{
    if(!err){
      if(data.length>0){
        // 查询总条数
        // data
        res.json({code:0,msg:'成功',data})
      }else{
        res.json({code:1,msg:'未查询到数据_总条数'})
      }
    }else{
      res.json({code:2,msg:'错误'})
    }
  })
})

router.get('/person_index.html', function(req, res, next) {
  res.render('person_index', { title:(req.session.user_nickname || '')+'个人中心',user_nickname:req.session.user_nickname || '请登录',
  user_sex:req.session.user_sex || '无',
  headlogo:req.session.headlogo || 'https://i1.douguo.com/static/img/70.jpg',
  user_descrip:req.session.user_descrip || '获取失败'});
  // res.render('person_index', { title:'个人中心'});
});

router.get('/person_updata.html',(req,res)=>{
res.render('person_updata',{title:'修改资料'})
})

// router.get('/person_otherindex.html', function(req, res, next) {
//   res.render('person_otherindex', { title:'个人中心'});
// });

//获取我的关注
router.get('/fouse_been_user.php',function(req,res,next){
  let userid=req.query.user_id;
  // console.log(req.query)
 if(userid){
  let sql='select user_id,user_nickname,headlogo,user_sex,user_name from users where user_id in(select f_been_user_id from focus where f_user_id=?)'
  db.connection(sql,[userid],(err,data)=>{
    if(!err){
      // console.log(data)
      if(data.length>0){
        res.json({
          code:0,
          msg:'关注列表获取成功',
          data,
        })
      }else{
        res.json({
          code:1,
          msg:'关注列表获取失败',
        })
      }
    }else{
      res.json({
        code:3,
        msg:'数据库连接失败，请检查代码',
      })
    }
  })
 }else{
  res.json({
    code:10,
    msg:'登录失效'
  })
 }
})

//此处被写死  获取关注我的人
router.get('/focus_user.php',function(req,res,next){
  let benn_id=req.query.been_user_id;
if(benn_id){
  let sql='select user_id,user_nickname,headlogo,user_sex,user_name from users where user_id in(select f_user_id from focus where f_been_user_id=?)'
db.connection(sql,[benn_id],(err,data)=>{
  if(!err){
    // console.log(data)
    if(data.length>0){
      res.json({
        code:0,
        msg:'关注列表获取成功',
        data,
      })
    }else{
      res.json({
        code:1,
        msg:'关注列表获取失败',
      })
    }
  }else{
    res.json({
      code:3,
      msg:'数据库连接失败，请检查代码',
    })
  }
  })
}else{
  res.json({
    code:10,
    msg:'登录失效'
  })
}
})

//判断 是否为互相关注  登录有效
router.get('/defaultbtn.php',(req,res)=>{
let one=req.query.one_id;
let two=req.query.two_id;
if(one){
  let sql='select * from focus where (f_user_id=? and f_been_user_id=?) or (f_user_id=? and f_been_user_id=?)'
  db.connection(sql,[one,two,two,one],(err,data)=>{
  if(!err){
    // console.log(data)
    if(data.length>0){
      res.json({
        code:0,
        msg:'获取成功',
        data,
      })
    }else{
      res.json({
        code:1,
        msg:'获取失败',
      })
    }
  }else{
    res.json({
      code:3,
      msg:'数据库连接失败，请检查代码',
    })
  }
})
}else{
  res.json({
    code:10,
    msg:'登录失效'
  })
}
})

// 删除关注对象 登录有效
router.get('/dropdata.php',function(req,res,next){
  let userid=req.query.user_id;
if(userid){
  let been_user_id=req.query.been_user_id;
let sql='delete from focus where f_user_id=? and f_been_user_id=?';
db.connection(sql,[userid,been_user_id],function(err,data){
  if(!err){
    res.json({
      code:0,
      msg:'删除成功',
    })
  }else{
    res.json({
      code:1,
      msg:'删除失败',
    })
  }
})
}else{
  res.json({
    code:10,
    msg:'登录失效'
  })
}
})

//添加关注对象 登录有效
router.get('/adddata.php',function(req,res,next){
let userid=req.query.user_id;
let been_user_id=req.query.been_user_id;
if(userid){
  let sql='insert into focus (f_user_id,f_been_user_id) values (?,?)';
  db.connection(sql,[userid,been_user_id],function(err,data){
  if(!err){
    res.json({
      code:0,
      msg:'添加成功',
    })
  }else{
    res.json({
      code:1,
      msg:'添加失败',
    })
  }
})
}else{
  res.json({
    code:10,
    msg:'登录失效'
  })
}
})

//获取发布菜谱  
router.get('/recipe.php',function(req,res,next){
  let userid=req.query.c_user_id;
if(userid){
  let sql='SELECT * FROM users,recipe WHERE users.user_id=recipe.author AND users.user_id=?'
db.connection(sql,[userid],(err,data)=>{
  if(!err){
    // console.log(data)
    if(data.length>0){
      res.json({
        code:0,
        msg:'发布菜谱获取成功',
        data,
      })
    }else{
      res.json({
        code:1,
        msg:'无菜谱发布或获取失败',
      })
    }
  }else{
    res.json({
      code:3,
      msg:'数据库连接失败，请检查代码',
    })
  }
})
}else{
  res.json({
    code:10,
    msg:'登录失效'
  })
}
})

//获取收藏
router.get('/collect.php',function(req,res,next){
let userid=req.query.c_user_id;
if(userid){
  let sql='select * from recipe where recipe_id in (select c_recipe_id from collect where c_user_id=?)'
  db.connection(sql,[userid],(err,data)=>{
  if(!err){
    // console.log(data)
    if(data.length>0){
      res.json({
        code:0,
        msg:'收藏菜谱获取成功',
        data,
      })
    }else{
      res.json({
        code:1,
        msg:'无收藏或获取失败',
      })
    }
  }else{
    res.json({
      code:3,
      msg:'数据库连接失败，请检查代码',
    })
  }
  })
}else{
  res.json({
    code:10,
    msg:'登录失效'
  })
}
})

//更改用户信息 基本资料
router.get('/updata_user.php',function(req,res,next){
let userid=req.query.user_id;
let signstr=req.query.signstr;
let usernickname=req.query.user_nickname;
let usersex=req.query.user_sex;
let userdescrip=req.query.user_descrip;
if(userid){
  let sql='update users set ';
  if(usernickname){
    sql+='user_nickname = ? ';
    sql+='where user_id = ?';
    db.connection(sql,[usernickname,userid],function(err,data){
      deal_with(err,data)
    });
  }
  if(usersex){
    sql+='user_sex = ? ';
    sql+='where user_id = ?';
    db.connection(sql,[usersex,userid],function(err,data){
      deal_with(err,data)
    });
  }
  if(userdescrip){
    sql+='user_descrip = ? ';
    sql+='where user_id = ?';
    db.connection(sql,[userdescrip,userid],function(err,data){
      deal_with(err,data)
    });
  }
  if(usernickname && usersex){
    sql+='user_nickname = ?, ';
    sql+='user_sex = ? ';
    sql+='where user_id = ?';
    db.connection(sql,[usernickname,usersex,userid],function(err,data){
      deal_with(err,data)
    });
  }
  if(usernickname && userdescrip){
    sql+='user_nickname = ?, ';
    sql+='user_descrip = ? ';
    sql+='where user_id = ?';
    db.connection(sql,[usernickname,userdescrip,userid],function(err,data){
      deal_with(err,data)
    });
  }
  if(userdescrip && usersex){
    sql+='user_sex = ?, ';
    sql+='user_descrip = ? ';
    sql+='where user_id = ?';
    db.connection(sql,[usersex,userdescrip,userid],function(err,data){
      deal_with(err,data)
    });
  }
  if(userdescrip && usersex && usernickname){
    sql+='user_nickname = ?, ';
    sql+='user_sex = ?, ';
    sql+='user_descrip = ? ';
    sql+='where user_id = ?';
    db.connection(sql,[usernickname,usersex,userdescrip,userid],function(err,data){
      deal_with(err,data)
    });
  }
  function deal_with(err,data){
      if(!err){
        res.json({
          code:1,
        })
      }
      else{
        res.json({
          code:2,
        })
      }
    }
}else{
  res.json({
    code:10,
    msg:'登录失效'
  })
}
})

module.exports = router;




