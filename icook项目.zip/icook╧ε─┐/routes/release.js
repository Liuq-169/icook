const express = require('express');
const router = express.Router();
const mysql=require('mysql')
const db=require('../utils/db.js')
const multer = require('multer');



//文字信息上传
  router.post('/uploadText.php',(req,res)=>{
    console.log('拦截成功');
    console.log(req.body);
  
    let author = req.body.author
    let recipe_title = req.body.recipe_title
    let recipe_keywords = req.body.recipe_keywords
    let info=req.body.info
    let img=req.body.img
    let recipe_step = req.body.recipe_step
    let uptime = req.body.uptime
    let collect = req.body.collect
    let sort_ingredients = req.body.sort_ingredients
    let sort_dish = req.body.sort_dish
    let sort_bake=req.body.sort_bake
    let sort_health = req.body.sort_health
    let like_num = req.body.like_num
    
   
    let sql=`INSERT INTO recipe(author,recipe_title,recipe_keywords,info,img,recipe_step,
                        uptime,collect,sort_ingredients,sort_dish,sort_bake,sort_health,like_num)
     VALUE (${author},'${recipe_title}','${recipe_keywords}','${info}','${img}','${recipe_step}',
            '${uptime}',${collect},${sort_ingredients},${sort_dish},${sort_bake},${sort_health},${like_num})`
    
//    let sql=`INSERT INTO recipe(sort_dish)VALUE(${sort_dish})`
    db.connection(sql,[author,recipe_title,recipe_keywords,info,img,recipe_step,uptime,collect,
        sort_ingredients,sort_dish,sort_bake,sort_health,like_num],
    //    db.connection(sql,[sort_dish],
    (err,data)=>{
        if (!err) {
            console.log(data);
           res.json({code:0,msg:'存入数据库成功'}) 
        } else {
            console.log(data);
          res.json({code:1,msg:'存数据库失败'})
        }
      })
  })

  //封面图片上传
  var storage = multer.diskStorage({
    destination: function(req,file,cb){
        // cb(null,'./static/img')
        cb(null,'./public/uploads')

        // <--BUG记录：这里的路径，虽然这里的files.js是在routes中，目标路径
        //         在本JS文件上级、在routes文件夹同级，但此处不用../而用./
        //         因为这个js文件是挂载到外面app.js文件中执行的，所以应该以
        //         app.js为基础查找-->
    },
    filename: function(req,file,cb){
        let exts = file.originalname.split('.')
        let ext = exts[exts.length-1]
        let tmpname=(new Date()).getTime()+parseInt(Math.random()*100)
        cb(null,`${tmpname}.${ext}`);
    } 
});
var upload = multer({ 
    storage: storage
});

router.post('/uploadImg.do',upload.single('hehe'),(req,res)=>{
    // console.log('拦截成功');
    let {size,mimetype,path}=req.file
    let types=['jpg','jpeg','png','gif']
    let tmpType = mimetype.split('/')[1]
    // let user_id = req.body.user_id
    let user_id=2
    if(size>50000000){
        return res.send({code:-1,msg:'尺寸过大'})
    }else if(types.indexOf(tmpType)==-1){
        return res.send({code:-2,msg:'媒体类型错误'})
    }else{
        let url = `/${req.file.filename}`
        res.send({code:0,msg:'ok',img:url})
    }
})

router.get('/getReleaseID.do',(req,res)=>{
    let sql=`SELECT recipe_id,sort_dish FROM recipe ORDER BY recipe_id DESC LIMIT 1`
    db.connection(sql,[],(err,data)=>{
        console.log(data);
        if(!err){
            res.json({
                code:0,
                msg:'查询id，菜式成功',
                recipe_id:data[0].recipe_id,
                sort_dish:data[0].sort_dish
            })
        }else{
            res.json({
                code:1,
                msg:'查询失败'
            })
        }
       
    })
})

  module.exports = router;