var express = require('express');
var router = express.Router();
const db=require('./../utils/db.js')
const stringRandom = require('string-random');

/* GET login listing. */
router.get('/', function(req, res, next) {
  res.send('respond with a resource');
});
//登录
router.post('/login.php',(req,res)=>{
    let username=req.body.username
    let password=req.body.password
    
    req.session.signstr=stringRandom(16, { numbers: true });
    console.log('签名字符串：',req.session.signstr);
    let sql='select * from users where user_name=? and password=?'
    db.connection(sql,[username,password],(err,data)=>{
      if(!err){
        if(data.length>=1){
          req.session.user_nickname=data[0].user_nickname
          req.session.user_sex=data[0].user_sex
          req.session.headlogo=data[0].headlogo
          req.session.user_descrip=data[0].user_descrip
          res.json({code:0,msg:'登陆成功',signstr:req.session.signstr,data:data})
        }else{
          res.json({code:1,msg:'登录失败,可能是用户名或密码错误'})
        }
      }else{
        res.json({code:2,msg:'登录失败'})
      }
    })
  })
//注册
router.get('/reg.php',(req,res)=>{
  let username=req.query.username
  let password=req.query.password
  let usernickname=req.query.usernickname
  let sql='insert into users (user_name,password,user_nickname) values (?,?,?)'
  db.connection(sql,[username,password,usernickname],(err,data)=>{
    if(!err){
          let sql='select * from users where user_name=? and password=? and user_nickname=?'
          db.connection(sql,[username,password,usernickname],(err,data)=>{
            if(!err){
              if(data.length>=1){
                res.json({code:0,msg:'注册成功，请登录',data_info:{username:username,data:data}})
              }else{
                res.json({code:1,msg:'注册失败,内部查询出错'})
              }
            }else{
              res.json({code:2,msg:'注册失败，内部查询err'})
            }
          })
    }else{
      res.json({code:3,msg:'注册失败,可能是用户名重复'})
    }
  })
})
//搜索
router.post('/search.php',(req,res)=>{
  let keywords=req.body.keywords
  let sql='SELECT * FROM users right OUTER JOIN recipe ON users.user_id=recipe.author where 1=1 and recipe_title like ? or recipe_keywords like ?'
  // let  sqla='SELECT * FROM users right OUTER JOIN recipe ON users.user_id=recipe.author'
  let keywordsh='%'+keywords+'%';
  db.connection(sql,[keywordsh,keywordsh],(err,data)=>{
    if(!err){
      if(data.length>=1){
        res.json({code:0,msg:'搜索成功',data:data})
      }else{
        res.json({code:1,msg:'搜索成功,没有你搜索的内容'})
      }
    }else{
      res.json({code:2,msg:'搜索失败'})
    }
  })
})
//搜索列表
router.post('/searchlist.php',(req,res)=>{
  let keywords=req.body.keywords
  let sql='SELECT * FROM users right OUTER JOIN recipe ON users.user_id=recipe.author where 1=1 and '
  let keywordsh='%'+keywords+'%';
  if(keywords==10){
    sql+='sort_ingredients like ?'
  }else if(keywords==20){
    sql+='sort_dish like ?'
  }else if(keywords==30){
    sql+='sort_bake like ?'
  }else if(keywords==40){
    sql+='sort_health like ?'
  }
  console.log(sql)
  db.connection(sql,[keywordsh],(err,data)=>{
    if(!err){
      if(data.length>=1){
        res.json({code:0,msg:'搜索成功',data:data})
      }else{
        res.json({code:1,msg:'搜索成功,没有你搜索的内容'})
      }
    }else{
      res.json({code:2,msg:'搜索失败'})
    }
  })
})
//搜索用户
router.post('/searchyh.php',(req,res)=>{
  let keywords=req.body.keywords
  let sql='SELECT * FROM users where 1=1 and user_nickname like ?'
  let keywordsh='%'+keywords+'%';
  console.log(sql)
  db.connection(sql,[keywordsh],(err,data)=>{
    if(!err){
      if(data.length>=1){
        res.json({code:0,msg:'搜索用户成功',data:data})
      }else{
        res.json({code:1,msg:'搜索用户成功,没有你搜索的内容'})
      }
    }else{
      res.json({code:2,msg:'搜索用户失败'})
    }
  })
})
//退出登录
router.get('/destroy.do',function(req,res){
  if(req.session.signstr){
    req.session.destroy()
    res.json({code:0,msg:'退出成功'})
  }else {
    res.json({code:1,msg:'登录超时'})
  }
})
//首页判断是否登录超时
router.post('/shuaxin.do',function(req,res){
  if(req.session.signstr){
    console.log('签名字符串：',req.session.signstr);
    res.json({code:0,msg:'已经登录'})
  }else {
    res.json({code:1,msg:'登录超时，或者没有登录'})
  }
})

module.exports = router;