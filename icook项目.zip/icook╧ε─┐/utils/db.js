const mysql = require('mysql')
module.exports={
    config:{
        host:'localhost',
        port:3306,
        user:'root',
        password:'root',
        database:'icoo',
        dateStrings:true
    },
    connection(sql,arr,callback){
        const pool = mysql.createPool(this.config)
        pool.getConnection((err,connection)=>{
            if(!err){
                connection.query(sql,arr,callback)
                connection.release()
            }else{
                return err
            }
        })
    }
}